#!/bin/bash
# install_kiosk.sh - Installs the Altered Reflections kiosk application.

set -e

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root." >&2
    exit 1
fi

echo "Installing Altered Reflections kiosk..."

# 1. Create user and directories
useradd -r -s /bin/false kiosk || echo "User 'kiosk' already exists."
mkdir -p /opt/altered-reflections

# 2. Copy application files
cp ../dist/altered-reflections /opt/altered-reflections/
cp altered_reflections.service /etc/systemd/system/

# 3. Set permissions
chown -R kiosk:kiosk /opt/altered-reflections
chmod 755 /opt/altered-reflections/altered-reflections

# 4. Reload systemd and enable the service
systemctl daemon-reload
systemctl enable altered_reflections.service

# 5. (Optional) Hide TTY switching for a more secure kiosk
# This prevents users from switching to a virtual console.
# MASK_PATH="/etc/systemd/system/getty@.service.d/override.conf"
# mkdir -p "$(dirname "$MASK_PATH")"
# cat > "$MASK_PATH" <<EOF
# [Unit]
# Mask=yes
# EOF

echo "Installation complete."
echo "You can start the service with: systemctl start altered_reflections.service"
