# Latent Self

Latent Self is an interactive art installation that transforms a user's webcam feed in real-time using StyleGAN and e4e. It creates an "altered reflection" by morphing the user's face along various latent directions (e.g., age, gender, ethnicity, species).

## Features

- Real-time face morphing using StyleGAN and e4e.
- Interactive controls for morphing directions.
- Admin panel for adjusting parameters.
- MQTT heartbeat for remote monitoring.
- Fallback behavior for camera failures.

## Setup and Installation

### Prerequisites

- Python 3.10+
- A webcam

### Model Weights

Download the following model weights and place them in a `weights/` directory in the project root:

- `ffhq-1024-stylegan2.pkl` (StyleGAN2-ADA generator)
- `e4e_ffhq_encode.pt` (e4e encoder)
- `latent_directions.npz` (Numpy file with unit vectors for AGE, GENDER, ETHNICITY, SPECIES)

### Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-repo/latent-self.git
    cd latent-self
    ```

2.  **Create a virtual environment (recommended):**
    ```bash
    python -m venv venv
    source venv/bin/activate
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

### Running the Application

To run the application with a basic OpenCV window:

```bash
python latent_self.py --camera 0 --resolution 512 --cuda
```

To run with the PyQt6 UI in kiosk mode:

```bash
python latent_self.py --ui qt --kiosk
```

## Usage

### Interactive Controls (OpenCV UI)

- `q`: Quit gracefully
- `a`: Morph along the 'Age' axis
- `g`: Morph along the 'Gender' axis
- `e`: Morph along the 'Ethnicity' axis
- `s`: Morph along the 'Species' axis
- `b`: Morph along a blend of all axes (default)

### Admin Panel (Qt UI only)

Press `F12` to open the admin panel. The default password is "admin".

## Configuration

The application uses `data/config.yaml` for default settings. On first run, this file is copied to `~/.latent_self/config.yaml`. You can modify the user-specific `config.yaml` to change parameters.

## Deployment

The `deploy/` directory contains scripts for kiosk deployment on Linux systems.

- `install_kiosk.sh`: Installs the application as a systemd service.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.
